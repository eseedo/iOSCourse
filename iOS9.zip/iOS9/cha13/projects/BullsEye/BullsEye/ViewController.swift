//
//  ViewController.swift
//  BullsEye
//
//  Created by eseedo on 10/3/38.
//  Copyright © 2015 CylonSpace. All rights reserved.
//  对虚拟现实感兴趣的朋友请访问赛隆网：http://www.cylonspace.com
//  虚拟现实社区：http://www.cylonspace.com/bbs
/*
“哈里·谢顿将川陀称作‘群星的尽头’，”他又细声说道，“为何不能是个诗意的意象呢?宇宙一度完全受到这个星体支配；所有的恒星都曾经跟此处保持联系；古谚有云，‘条条大路通川陀’——这里才是群星真正的尽头。”

　　十个月以前，首席发言者曾站在同一个地点，满怀沉重的心情，抬头凝视着拥挤的星空——在人类称为“银河系”的这个巨大物质团块，再也没有比中心处更拥挤的区域。如今，在那张浑圆、红润、朴素的脸庞上，首席发言者——普芮姆·帕佛——微微现出了一个满意的神情。
*/

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var slider: UISlider!
    @IBOutlet weak var targetLabel:UILabel!
    @IBOutlet weak var scoreLabel:UILabel!
    @IBOutlet weak var roundLabel:UILabel!
    
    var currentValue: Int = 0
    var targetValue: Int  = 0
    var score = 0
    var round = 0

    override func viewDidLoad() {
        super.viewDidLoad()
        startNewGame()
        updateLabels()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func showAlert(){
        
        let difference = abs(currentValue - targetValue)
        var points = 100 - difference
        score += points
        
        var title: String
        
        if difference == 0{
            title = "完美！你可以买彩票去了！";
            points += 100
        }else if difference < 5{
            title = "土豪求抱大腿";
            points += 50
        }else if difference < 10{
            title = "我会让你明白，良辰从不说空话";
        }else{
            title = "你若是感觉有实力跟我玩，良辰不介意奉陪到底~";
        }
        
        let message = "赵日天大人，您的得分是： \(points)"
        
        let alert = UIAlertController(title: title, message: message, preferredStyle: .Alert)
        
        let action = UIAlertAction(title: "太NB了", style: .Default,
                                   handler:{ action in
                                             self.startNewRound()
                                             self.updateLabels()
            
                                    })
        
        alert.addAction(action)
        
        presentViewController(alert, animated: true, completion: nil)
        

    }

    @IBAction func sliderMoved(slider:UISlider){
//        print("滑动条的当前数值是：\(slider.value)")
        currentValue = lroundf(slider.value)
    }
    
    @IBAction func startOver(){
        startNewGame()
        updateLabels()
    }

    //开启新的游戏回合
    func startNewRound(){
        round += 1
        
        targetValue = 1 + Int(arc4random_uniform(100))
        currentValue = 50
        slider.value = Float(currentValue)
    }
    
    //开启新的游戏
    func startNewGame(){
        score = 0
        round = 0
        startNewRound()
    }
    
    //更新标签的数值
    func updateLabels(){
        targetLabel.text = String(targetValue)
        scoreLabel.text = String(score)
        roundLabel.text = String(round)
    }
    
}

