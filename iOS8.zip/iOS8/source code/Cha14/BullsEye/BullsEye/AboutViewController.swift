//
//  AboutViewController.swift
//  BullsEye
//
//  Created by eseedo on 10/6/14.
//  Copyright (c) 2014 eseedo. All rights reserved.
//

import UIKit

class AboutViewController: UIViewController {


    @IBOutlet weak var webView: UIWebView!
    
    @IBAction func close(){
        
        dismissViewControllerAnimated(true, completion: nil);
    }

    override func  viewDidLoad() {
        
        super.viewDidLoad()
        
//        if let htmlFile = NSBundle.mainBundle().pathForResource("BullsEye", ofType: "html"){
//   
//        let htmlData = NSData(contentsOfFile: htmlFile)
//        
//        let baseURL = NSURL.fileURLWithPath(NSBundle.mainBundle().bundlePath)
//        
//        webView.loadData(htmlData, MIMEType: "text/html", textEncodingName: "UTF-8", baseURL: baseURL)
//            
//        }
        
        let url = NSURL.URLWithString("http://www.apple.com")
        var request: NSURLRequest = NSURLRequest(URL: url)
        webView.loadRequest(request)
        
    }
    
}
