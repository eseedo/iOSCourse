//
//  ViewController.swift
//  BullsEye
//
//  Created by eseedo on 9/24/14.
//  Copyright (c) 2014 eseedo. All rights reserved.
//


import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var slider:UISlider!
    @IBOutlet weak var targetLabel: UILabel!
    @IBOutlet weak var scoreLabel: UILabel!
    @IBOutlet weak var roundLabel: UILabel!
    
//    var currentValue: Int = 50
//    
//    var targetValue: Int = 0
    
    var currentValue = 50
    var targetValue = 0
    
    var score = 0
    
    var round = 0

    override func viewDidLoad() {
        super.viewDidLoad()
        startNewRound()
        updateLabels()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func startNewRound(){
        
        round += 1
        
        targetValue = 1 + Int(arc4random_uniform(100))
        
        currentValue = 50
        
        slider.value = Float(currentValue)
        
    }
    
    func updateLabels(){
        targetLabel.text = String(targetValue)
        scoreLabel.text = String(score)
        roundLabel.text = String(round)
    }


    @IBAction func showAlert(){
        
        let difference = abs(targetValue - currentValue)
        
        var points = 100 - difference
        
        score += points
        
        var title: String
        
        if difference == 0{
            title = "完美！你可以买彩票去了！"
            points += 100
        }else if difference < 5 {
            title = "这运气可以中二等奖了！"
            
            if difference == 1 {
            points += 50
            }
        }else if difference < 10 {
            title = "貌似还不错"
        }else {
            title = "就这水平你还敢来玩耍？。。。"
        }

        
        let message = "大侠，您的得分是 \(points)"
        
        let alert = UIAlertController(title: title,
                                      message: message,
                                      preferredStyle: .Alert)
        
        let action = UIAlertAction(title: "爱卿辛苦了",
                                   style:  .Default,
                                    handler: { action in
                                        self.startNewRound()
                                        self.updateLabels()
                                    })
        
        alert.addAction(action)
        
        presentViewController(alert,animated: true, completion: nil)

    }
    
    @IBAction func sliderMoved(slider: UISlider){
        
//        println("滑动条的当前数值是： \(slider.value)")
        currentValue = lroundf(slider.value)
        
    }
}

/* 以下内容来自苹果公司当年著名的Think Different 广告

                                Think Different

                    Here's to the crazy ones.献给狂放不羁的一群人
                                       The misfits.  他们是：不和主流的怪才
                                       The rebels.  叛逆传统的勇士
                               The troublemakers.  制造麻烦的一笑撮
                The round pegs in the square holes.  方凿圆枘、特立独行
                The ones who see things differently.  他们观察问题与众不同
                        They are not fond of rules.  他们不喜欢条条框框
        And they have no respect for the status quo.  更不把正统放在眼里
                              You can quote them,  你可以引用他们，
                               disagree with them,  也可以否决他们，
                               glorify or vilify them.  赞扬或是诋毁他们
                  About the only thing you can't do,  但只有一件事你不能做
                                   is ignore them.  那就是漠视他们
                      Because they change things.  因为他们改变了事物
                They push the human race forward.  他们推动了人类的进程
        And while some see them as the crazy ones,  虽然有些人把他们当作疯子
                                  We see genius.  但我们看见的却是天才
Because the people who are crazy enough to think 因为只有那些足够疯狂认为
                       they can change the world,  可以改变世界的人
                            Are the ones who do.  才能真正做到这一点

*/
