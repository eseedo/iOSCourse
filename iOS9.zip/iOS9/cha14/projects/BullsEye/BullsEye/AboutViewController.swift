//
//  AboutViewController.swift
//  BullsEye
//
//  Created by eseedo on 10/3/38.
//  Copyright © 2015 CylonSpace. All rights reserved.
//
//  对虚拟现实感兴趣的朋友请访问赛隆网：http://www.cylonspace.com

//  虚拟现实社区：http://www.cylonspace.com/bbs
/*
　　接着，由杜森·巴尔所率领的西维纳代表团，代表西维纳新政府在“公约”上签字，西维纳从此正式加入基地体系。从帝国的政治势力脱离，直接转移到基地的经济联盟，西维纳是有史以来首开先例的第一个星省。

　　此时，五艘帝国舰队的星舰掠过天空——它们是在西维纳的起义中，被俘虏的皇家边境舰队星舰。这五艘硕大的星际战舰排列整齐划过天空，并且在通过市中心时一齐发出巨响，向地面的贵宾致敬。
*/

import UIKit

class AboutViewController: UIViewController {
    
    @IBOutlet weak var webView: UIWebView!

    @IBAction func close(){
        dismissViewControllerAnimated(true, completion: nil)
    }
    
    override func viewDidLoad(){
        
        super.viewDidLoad()
        
//        //加载html页面
//        
//        if let htmlFile = NSBundle.mainBundle().pathForResource("BullsEye",
//                                                        ofType: "html"){
//            if let htmlData = NSData(contentsOfFile: htmlFile){
//                let baseURL = NSURL(fileURLWithPath: NSBundle.mainBundle().bundlePath)
//                webView.loadData(htmlData, MIMEType: "text/html", textEncodingName: "UTF-8", baseURL: baseURL)
//                                                            }
//        }
        
        //加载web页面
        
        let url = NSURL(string:"http://www.cylonspace.com")!
        let request: NSURLRequest = NSURLRequest(URL: url)
        webView.loadRequest(request)
        
    }

}
