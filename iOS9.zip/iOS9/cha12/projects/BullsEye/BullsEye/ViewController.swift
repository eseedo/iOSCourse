//
//  ViewController.swift
//  BullsEye
//
//  Created by eseedo on 10/3/15.
//  Copyright © 2015 CylonSpace. All rights reserved.
//  对虚拟现实感兴趣的朋友请访问赛隆网：http://www.cylonspace.com
//  虚拟现实社区：http://www.cylonspace.com/bbs

/* 我会告诉你这是一段长长的注释吗？~
慈祥的人坐在黑白之院的水池边等她，丑女孩坐到他身旁，把一枚钱币放在他们之间的池边上。那是枚金币，一面画龙，另一面是国王。

“维斯特洛金龙。”慈祥的人说，“你怎么拿到的？我们不是贼。”

“这不算偷。我从他那儿拿走一枚，留下一枚我们的。”

慈祥的人明白了。“他会把我们的钱币和其他钱币一起装进钱包，付给那个人，那个人的心脏不久就要停止跳动。是这样吧？真伤感。”牧师拾起钱币，抛进池子，“你还有很多要学，但也许是个可塑之才。”

当晚，他们给她换回艾莉亚·史塔克的脸。

他们还给了她柔软厚实的侍僧袍子，一边黑一边白。“在这里穿这个，”牧师说，“但你目前不怎么需要它。明天，你去伊兹巴洛那里开始第一个学徒期。现在下地窖找些衣服，城市守卫正在抓捕紫港出了名的丑女孩，所以你最好也换张脸。”他扳住她下巴，把她的头转来转去，最终点点头。“这次换张漂亮的，和你自己一样漂亮。你是谁，孩子？”

“无名之辈。”她回答。
*/

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var slider: UISlider!
    @IBOutlet weak var targetLabel:UILabel!
    @IBOutlet weak var scoreLabel:UILabel!
    @IBOutlet weak var roundLabel:UILabel!
    
    var currentValue: Int = 50
    var targetValue: Int  = 0
    var score = 0
    var round = 0

    override func viewDidLoad() {
        super.viewDidLoad()
        startNewGame()
        updateLabels()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func showAlert(){
        
        let difference = abs(currentValue - targetValue)
        var points = 100 - difference
        score += points
        
        var title: String
        
        if difference == 0{
            title = "完美！你可以买彩票去了！";
            points += 100
        }else if difference < 5{
            title = "土豪求抱大腿";
            points += 50
        }else if difference < 10{
            title = "我会让你明白，良辰从不说空话";
        }else{
            title = "你若是感觉有实力跟我玩，良辰不介意奉陪到底~";
        }
        
        let message = "赵日天大人，您的得分是： \(points)"
        
        let alert = UIAlertController(title: title, message: message, preferredStyle: .Alert)
        
        let action = UIAlertAction(title: "太NB了", style: .Default,
                                   handler:{ action in
                                             self.startNewRound()
                                             self.updateLabels()
            
                                    })
        
        alert.addAction(action)
        
        presentViewController(alert, animated: true, completion: nil)
        

    }

    @IBAction func sliderMoved(slider:UISlider){
//        print("滑动条的当前数值是：\(slider.value)")
        currentValue = lroundf(slider.value)
    }
    
    @IBAction func startOver(){
        startNewGame()
        updateLabels()
    }

    //开启新的游戏回合
    func startNewRound(){
        round += 1
        
        targetValue = 1 + Int(arc4random_uniform(100))
        currentValue = 50
        slider.value = Float(currentValue)
    }
    
    //开启新的游戏
    func startNewGame(){
        score = 0
        round = 0
        startNewRound()
    }
    
    //更新标签的数值
    func updateLabels(){
        targetLabel.text = String(targetValue)
        scoreLabel.text = String(score)
        roundLabel.text = String(round)
    }
    
}

