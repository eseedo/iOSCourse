//
//  ViewController.swift
//  BullsEye
//
//  Created by eseedo on 10/2/15.
//  Copyright © 2015 CylonSpace. All rights reserved.
//  对虚拟现实感兴趣的朋友请访问赛隆网：http://www.cylonspace.com
//  虚拟现实社区：http://www.cylonspace.com/bbs

/* 我会告诉你这是一段长长的注释吗？~你可以在这里写小说了。
来自马丁本人流出的卷六章节有人知道哪儿有吗？

十几次心跳后，他们便超越了下方疾驰的多斯拉克斥候。丹妮看到左右都有焚成灰烬的草地。卓耿来过这里，她意识到。他狩猎的痕迹犹如一串灰色岛屿，点缀在绿海汪洋中。

一大群马匹出现在下方，那是二十多个骑手，但他们一看到龙转身就逃。黑影欺近他们，马群吓破了胆，在草原上撒开蹄子狂奔，直到口吐白沫，四蹄撕裂大地……但它们再快也飞不起来。一匹马落了单，黑龙咆哮着下降，眨眼间那可怜的牲畜就浑身浴火，但还没停下奔跑的步伐，一路尖锐的哀鸣，直到卓耿落在它身上，折断它的脊背。丹妮用尽全力抓住黑龙的脖子，才没滑下去。

马尸太沉，卓耿没法运回龙石山，于是就地享受猎物。他从兽尸上扯下焦肉，周围的青草熊熊燃烧，空中弥漫着浓烟和烧焦马毛的气味。饥饿的丹妮从龙背上滑下，和他一同进食，赤手从死马上扯下几块冒烟的肉。她烧伤了双手。在弥林，我是丝绸包裹的女王，小口地咬着塞满枣子的蜂蜜烤羊，她回忆，我那高贵的夫君看到我现在的模样会作何感想？西茨达拉肯定会被吓坏。但达里奥……

达里奥会哈哈大笑，抽出亚拉克弯刀割下一大块马肉，蹲在她身旁一起吃。

当西方的天空变成淤血的颜色，丹妮听见马蹄声。她站起来，用残破的内衣擦净双手。

贾科卡奥带着五十名骑马战士从滚滚浓烟中出现时，丹妮莉丝和她的龙站在一起。

*/

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var slider: UISlider!
    @IBOutlet weak var targetLabel:UILabel!
    
    var currentValue: Int = 50
    var targetValue: Int  = 0

    override func viewDidLoad() {
        super.viewDidLoad()
        startNewRound()
        updateLabels()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func showAlert(){
        
        let message = "滑动条的当前数值是： \(currentValue)"
                    + "\n目标数值是： \(targetValue)"
        
        let alert = UIAlertController(title: "你好，火星人", message: message, preferredStyle: .Alert)
        
        let action = UIAlertAction(title: "太NB了", style: .Default, handler: nil)
        
        alert.addAction(action)
        
        presentViewController(alert, animated: true, completion: nil)
        
        //开启新的游戏回合
        startNewRound()
        
        updateLabels()
    }

    @IBAction func sliderMoved(slider:UISlider){
//        print("滑动条的当前数值是：\(slider.value)")
        currentValue = lroundf(slider.value)
    }

    //开启新的游戏回合
    func startNewRound(){
        
        targetValue = 1 + Int(arc4random_uniform(100))
        currentValue = 50
        slider.value = Float(currentValue)
    }
    
    //更新标签的数值
    func updateLabels(){
        targetLabel.text = String(targetValue)
    }
    
}

