//
//  AboutViewController.swift
//  BullsEye
//
//  Created by eseedo on 10/6/14.
//  Copyright (c) 2014 eseedo. All rights reserved.
//

import UIKit

class AboutViewController: UIViewController {


    @IBAction func close(){
        
        dismissViewControllerAnimated(true, completion: nil);
    }

}
