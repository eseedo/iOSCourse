//
//  AboutViewController.swift
//  BullsEye
//
//  Created by eseedo on 10/3/15.
//  Copyright © 2015 CylonSpace. All rights reserved.
//

import UIKit

class AboutViewController: UIViewController {

    @IBAction func close(){
        dismissViewControllerAnimated(true, completion: nil)
    }

}
