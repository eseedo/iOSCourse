//
//  ViewController.swift
//  BullsEye
//
//  Created by eseedo on 10/3/38.
//  Copyright © 2015 CylonSpace. All rights reserved.
//  对虚拟现实感兴趣的朋友请访问赛隆网：http://www.cylonspace.com
//  虚拟现实社区：http://www.cylonspace.com/bbs
/*
庭前花木满 院外小径芳
四时常相往 晴日共剪窗
*/

import UIKit
import QuartzCore
import AVFoundation

class ViewController: UIViewController {
    
    @IBOutlet weak var slider: UISlider!
    @IBOutlet weak var targetLabel:UILabel!
    @IBOutlet weak var scoreLabel:UILabel!
    @IBOutlet weak var roundLabel:UILabel!
    
    var currentValue: Int = 50
    var targetValue: Int  = 0
    var score = 0
    var round = 0
    
    //播放音乐
    var audioPlayer: AVAudioPlayer!
    


    override func viewDidLoad() {
        super.viewDidLoad()
        startNewGame()
        updateLabels()
        //播放背景音乐
        playBgMusic()
        
        //更改slider滑动条的外观
        let thumbImageNormal = UIImage(named: "SliderThumb-Normal")
        slider.setThumbImage(thumbImageNormal, forState: .Normal)
        
        let thumbImageHighlighted = UIImage(named: "SliderThumb-Highlighted")
        slider.setThumbImage(thumbImageHighlighted, forState: .Highlighted)
        
        
        let insets = UIEdgeInsets(top: 0, left: 14, bottom: 0, right: 14)
        
        if let trackLeftImage = UIImage(named: "SliderTrackLeft"){
            let trackLeftResizable = trackLeftImage.resizableImageWithCapInsets(insets)
            slider.setMinimumTrackImage(trackLeftResizable, forState: .Normal)
        }
        
        
        if let trackRightImage = UIImage(named: "SliderTrackRight"){
            let trackRightResizable = trackRightImage.resizableImageWithCapInsets(insets)
            slider.setMaximumTrackImage(trackRightResizable, forState: .Normal)
        }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func showAlert(){
        
        let difference = abs(currentValue - targetValue)
        var points = 100 - difference
        score += points
        
        var title: String
        
        if difference == 0{
            title = "完美！你可以买彩票去了！";
            points += 100
        }else if difference < 5{
            title = "土豪求抱大腿";
            points += 50
        }else if difference < 10{
            title = "我会让你明白，良辰从不说空话";
        }else{
            title = "你若是感觉有实力跟我玩，良辰不介意奉陪到底~";
        }
        
        let message = "赵日天大人，您的得分是： \(points)"
        
        let alert = UIAlertController(title: title, message: message, preferredStyle: .Alert)
        
        let action = UIAlertAction(title: "太NB了", style: .Default,
                                   handler:{ action in
                                             self.startNewRound()
                                             self.updateLabels()
            
                                    })
        
        alert.addAction(action)
        
        presentViewController(alert, animated: true, completion: nil)
        

    }

    @IBAction func sliderMoved(slider:UISlider){
//        print("滑动条的当前数值是：\(slider.value)")
        currentValue = lroundf(slider.value)
    }
    
    @IBAction func startOver(){
        startNewGame()
        updateLabels()
        
        //添加界面切换效果
        let transition = CATransition()
        transition.type = kCATransitionFade
        transition.duration = 1
        transition.timingFunction = CAMediaTimingFunction(name: kCAMediaTimingFunctionEaseOut)
        view.layer.addAnimation(transition, forKey: nil)
    }

    //开启新的游戏回合
    func startNewRound(){
        round += 1
        
        targetValue = 1 + Int(arc4random_uniform(100))
        currentValue = 50
        slider.value = Float(currentValue)
    }
    
    //开启新的游戏
    func startNewGame(){
        score = 0
        round = 0
        startNewRound()
    }
    
    //更新标签的数值
    func updateLabels(){
        targetLabel.text = String(targetValue)
        scoreLabel.text = String(score)
        roundLabel.text = String(round)
    }
    
    //播放背景音乐
    func playBgMusic(){
        
        let musicPath = NSBundle.mainBundle().pathForResource("bgmusic", ofType: "mp3")
        let url = NSURL(fileURLWithPath: musicPath!)
        
        do{
            audioPlayer = try AVAudioPlayer(contentsOfURL: url)
        }catch _ {
            audioPlayer = nil
        }
        audioPlayer.numberOfLoops = -1
        audioPlayer.prepareToPlay()
        audioPlayer.play()
    }
    
}

