//
//  AboutViewController.swift
//  BullsEye
//
//  Created by eseedo on 10/3/38.
//  Copyright © 2015 CylonSpace. All rights reserved.
//
//  对虚拟现实感兴趣的朋友请访问赛隆网：http://www.cylonspace.com
/*良辰大人的经典语录
1、你只需要记住，我叫叶良辰。
2、呵呵，我会让你们明白，良辰从不说空话。
3、别让我去你们那破学校找你，我是本地的，我有一百种方法让你们待不下去，可你们，却无可奈何。
4、呵呵，良辰最喜欢对那些自认为能力出众的人出手。
5、你们只需要记住，我叫叶良辰。
6、无妨，你们可以把所有认识的人全部叫出来，良辰不介意陪你们玩玩，若我赢了，你们给我乖乖滚出宿舍，别欺人太甚。
7、你若是感觉有实力跟我玩，良辰不介意奉陪到底。
8、当然，若是你们就此罢手，那良辰在此多谢了，他日，必有重谢。
*/

import UIKit

class AboutViewController: UIViewController {

    @IBAction func close(){
        dismissViewControllerAnimated(true, completion: nil)
    }

}
