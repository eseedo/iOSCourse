//
//  ViewController.swift
//  BullsEye
//
//  Created by eseedo on 10/2/15.
//  Copyright © 2015 CylonSpace. All rights reserved.
//  对虚拟现实感兴趣的朋友请访问赛隆网：http://www.cylonspace.com
//  虚拟现实社区：http://www.cylonspace.com/bbs

/* 我会告诉你这是一段长长的注释吗？~

我有一个梦，也许有一天，灿烂的阳光能照进黑暗森林。这时，这里的太阳却在落下去，现在只在远山上露出顶端的一点，像山顶上镶嵌着的一块光灿灿的宝石。孩子已经跑远，同草地一起沐浴在金色的晚霞之中。

　　太阳快落下去了，你们的孩子居然不害怕？当然不害怕，她知道明天太阳还会升起来的。
*/

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var slider: UISlider!
    @IBOutlet weak var targetLabel:UILabel!
    @IBOutlet weak var scoreLabel:UILabel!
    @IBOutlet weak var roundLabel:UILabel!
    
    var currentValue: Int = 50
    var targetValue: Int  = 0
    var score = 0
    var round = 0

    override func viewDidLoad() {
        super.viewDidLoad()
        startNewRound()
        updateLabels()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func showAlert(){
        
        let difference = abs(currentValue - targetValue)
        var points = 100 - difference
        score += points
        
        var title: String
        
        if difference == 0{
            title = "完美！你可以买彩票去了！";
            points += 100
        }else if difference < 5{
            title = "土豪求抱大腿";
            points += 50
        }else if difference < 10{
            title = "我会让你明白，良辰从不说空话";
        }else{
            title = "你若是感觉有实力跟我玩，良辰不介意奉陪到底~";
        }
        
        let message = "赵日天大人，您的得分是： \(points)"
        
        let alert = UIAlertController(title: title, message: message, preferredStyle: .Alert)
        
        let action = UIAlertAction(title: "太NB了", style: .Default,
                                   handler:{ action in
                                             self.startNewRound()
                                             self.updateLabels()
            
                                    })
        
        alert.addAction(action)
        
        presentViewController(alert, animated: true, completion: nil)
        

    }

    @IBAction func sliderMoved(slider:UISlider){
//        print("滑动条的当前数值是：\(slider.value)")
        currentValue = lroundf(slider.value)
    }

    //开启新的游戏回合
    func startNewRound(){
        round += 1
        
        targetValue = 1 + Int(arc4random_uniform(100))
        currentValue = 50
        slider.value = Float(currentValue)
    }
    
    //更新标签的数值
    func updateLabels(){
        targetLabel.text = String(targetValue)
        scoreLabel.text = String(score)
        roundLabel.text = String(round)
    }
    
}

