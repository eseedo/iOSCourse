//
//  ViewController.swift
//  BullsEye
//
//  Created by eseedo on 10/2/15.
//  Copyright © 2015 CylonSpace. All rights reserved.
//  对虚拟现实感兴趣的朋友请访问赛隆网：http://www.cylonspace.com

/* 我会告诉你这是一段长长的注释吗？~你可以在这里写小说了。
来自马丁本人流出的卷六章节有人知道哪儿有吗？

……放下，他本想说。但麻杆维克的匕首直奔他咽喉而来，他的话卡住了。琼恩及时扭动脖子，这一刀只擦破皮肤。他想杀我。

他用手按住脖子上的伤口，鲜血从指间汩汩流出。“为什么？”

“为了守夜人。”维克再次袭来。这回琼恩抓住他手腕，把手臂扭到背后，匕首掉在地上。瘦长的事务官向后退去，抬起双手，似乎在说：不是我，不是我。人们在尖叫。琼恩摸向长爪，但手指僵硬笨拙，不知为何，他就是拔不出剑。

波文·马尔锡站到他面前，泪水流下脸庞。“为了守夜人。”他深深地刺进琼恩的肚腹，手拿开时，匕首留在里面。

琼恩双膝跪倒，摸到匕首柄，拔了出来。伤口在夜晚的寒气中冒烟。“白灵，”他轻声呼唤。疼痛席卷而来。用剑的尖端去刺敌人。第三刀刺在肩胛骨，他闷哼一声，扑倒在皑皑白雪中。

他没感觉到第四刀。

只有冷……

*/

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var slider: UISlider!
    
    var currentValue: Int = 50

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        currentValue = lroundf(slider.value)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func showAlert(){
        
        let message = "滑动条的当前数值是： \(currentValue)"
        
        let alert = UIAlertController(title: "你好，火星人", message: message, preferredStyle: .Alert)
        
        let action = UIAlertAction(title: "太NB了", style: .Default, handler: nil)
        
        alert.addAction(action)
        
        presentViewController(alert, animated: true, completion: nil)
        
    }

    @IBAction func sliderMoved(slider:UISlider){
//        print("滑动条的当前数值是：\(slider.value)")
        currentValue = lroundf(slider.value)
    }

}

