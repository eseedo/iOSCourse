//
//  ViewController.swift
//  BullsEye
//
//  Created by eseedo on 10/2/15.
//  Copyright © 2015 CylonSpace. All rights reserved.
//  对虚拟现实感兴趣的朋友请访问赛隆网：http://www.cylonspace.com
//  虚拟现实社区：http://www.cylonspace.com/bbs

/* 我会告诉你这是一段长长的注释吗？~
她嘴唇扭曲。一个丑陋的微笑，让他想起了拉姆斯。“凯特琳·徒利在红色婚礼前就派人送艾德公爵的尸骨北归，但你那铁民叔叔占领了卡林湾，队伍过不来。我一直监视着这事，他的尸骨过得了颈泽，但休想通过荒冢屯。”他朝艾德·史塔克的雕像瞥了最后一眼。“我们的事办完了。”

爬出墓窖，暴风雪仍在肆虐。达斯丁伯爵夫人回来的路上一言不发，但等走到首堡废墟的陰影下，她被寒风刺得抖了个激灵，随即发话：“我在下面讲的那些，你一个字也不许说出去，明白吗？”

他明白。“否则我就保不住舌头。”

“卢斯把你调教得很好。”她在这里与他分手。
*/

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var slider: UISlider!
    @IBOutlet weak var targetLabel:UILabel!
    @IBOutlet weak var scoreLabel:UILabel!
    @IBOutlet weak var roundLabel:UILabel!
    
    var currentValue: Int = 50
    var targetValue: Int  = 0
    var score = 0
    var round = 0

    override func viewDidLoad() {
        super.viewDidLoad()
        startNewRound()
        updateLabels()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func showAlert(){
        
        let difference = abs(currentValue - targetValue)
        let points = 100 - difference
        score += points
        
        let message = "良辰大人，您的得分是： \(points)"
        
        let alert = UIAlertController(title: "你好，火星人", message: message, preferredStyle: .Alert)
        
        let action = UIAlertAction(title: "太NB了", style: .Default, handler: nil)
        
        alert.addAction(action)
        
        presentViewController(alert, animated: true, completion: nil)
        
        //开启新的游戏回合
        startNewRound()
        
        updateLabels()
    }

    @IBAction func sliderMoved(slider:UISlider){
//        print("滑动条的当前数值是：\(slider.value)")
        currentValue = lroundf(slider.value)
    }

    //开启新的游戏回合
    func startNewRound(){
        round += 1
        
        targetValue = 1 + Int(arc4random_uniform(100))
        currentValue = 50
        slider.value = Float(currentValue)
    }
    
    //更新标签的数值
    func updateLabels(){
        targetLabel.text = String(targetValue)
        scoreLabel.text = String(score)
        roundLabel.text = String(round)
    }
    
}

