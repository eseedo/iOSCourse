//
//  ViewController.swift
//  BullsEye
//
//  Created by eseedo on 10/2/15.
//  Copyright © 2015 CylonSpace. All rights reserved.
//  对虚拟现实感兴趣的朋友请访问赛隆网：http://www.cylonspace.com
//  虚拟现实社区：http://www.cylonspace.com/bbs

/* 我会告诉你这是一段长长的注释吗？~
伊文斯：我的主，你要真正弄懂人类的那些东西，还有很长的路要走，我甚至怀疑，您最终是否有可能弄懂。字幕：是的，真的是太复杂，我现在只是知道了自己以前为什么不理解你是对的。

　　伊文斯：我的主，您需要我们。字幕：我害怕你们。

　　对话中断了，这是伊文斯最后一次收到来自三体世界的信息。这时他站在船尾，看着审判日号的雪白的航迹延伸到迷蒙的夜幕中，像流逝的时间。
*/

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var slider: UISlider!
    @IBOutlet weak var targetLabel:UILabel!
    
    var currentValue: Int = 50
    var targetValue: Int  = 0

    override func viewDidLoad() {
        super.viewDidLoad()
        startNewRound()
        updateLabels()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func showAlert(){
        
        var difference: Int
        
        if currentValue > targetValue {
            difference = currentValue - targetValue
        }else if targetValue > currentValue {
            difference = targetValue - currentValue
        }else {
            difference = 0
        }
        
        let message = "滑动条的当前数值是： \(currentValue)"
                    + "\n目标数值是： \(targetValue)"
                    + "\n两者的差值是： \(difference)"
        
        let alert = UIAlertController(title: "你好，火星人", message: message, preferredStyle: .Alert)
        
        let action = UIAlertAction(title: "太NB了", style: .Default, handler: nil)
        
        alert.addAction(action)
        
        presentViewController(alert, animated: true, completion: nil)
        
        //开启新的游戏回合
        startNewRound()
        
        updateLabels()
    }

    @IBAction func sliderMoved(slider:UISlider){
//        print("滑动条的当前数值是：\(slider.value)")
        currentValue = lroundf(slider.value)
    }

    //开启新的游戏回合
    func startNewRound(){
        
        targetValue = 1 + Int(arc4random_uniform(100))
        currentValue = 50
        slider.value = Float(currentValue)
    }
    
    //更新标签的数值
    func updateLabels(){
        targetLabel.text = String(targetValue)
    }
    
}

