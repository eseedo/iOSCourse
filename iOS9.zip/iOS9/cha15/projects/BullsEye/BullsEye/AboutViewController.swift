//
//  AboutViewController.swift
//  BullsEye
//
//  Created by eseedo on 10/3/38.
//  Copyright © 2015 CylonSpace. All rights reserved.
//
//  对虚拟现实感兴趣的朋友请访问赛隆网：http://www.cylonspace.com
//  虚拟现实社区：http://www.cylonspace.com/bbs
/*
古老的共和国”是传奇的共和国，它的广袤无垠和悠久永恒远非时间和距离所能衡量。不必追溯它的起源，也不必寻求它的方位……它就是宇宙这一方的独一无二的共和国。
　　在参议院的英明治理和杰迪骑土们的保卫下，共和国一度十分兴旺发达。然而，事物的发展往往就是这样：当财富和权力从受人倾慕而膨胀到令人畏惧时，奸邪之徒就会应运而生。
　　他们贪得无厌，渐荫觊觎之心。
　　共和国就是这样地处在物极必反的转折关头。犹如一棵无与伦比的参天大树，虽然还能经受外来风雨的侵袭，内里却已蛀空，只是认表面上还看不出危亡的迹象罢了。
*/

import UIKit

class AboutViewController: UIViewController {
    
    @IBOutlet weak var webView: UIWebView!

    @IBAction func close(){
        dismissViewControllerAnimated(true, completion: nil)
    }
    
    override func viewDidLoad(){
        
        super.viewDidLoad()
        
//        //加载html页面
//        
//        if let htmlFile = NSBundle.mainBundle().pathForResource("BullsEye",
//                                                        ofType: "html"){
//            if let htmlData = NSData(contentsOfFile: htmlFile){
//                let baseURL = NSURL(fileURLWithPath: NSBundle.mainBundle().bundlePath)
//                webView.loadData(htmlData, MIMEType: "text/html", textEncodingName: "UTF-8", baseURL: baseURL)
//                                                            }
//        }
        
        //加载web页面
        
        let url = NSURL(string:"http://www.cylonspace.com")!
        let request: NSURLRequest = NSURLRequest(URL: url)
        webView.loadRequest(request)
        
    }

}
